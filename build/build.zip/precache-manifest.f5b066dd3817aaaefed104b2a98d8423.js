self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "39e78eec5148ae97210dff1e77005839",
    "url": "/index.html"
  },
  {
    "revision": "aca2805ad2c9169e54da",
    "url": "/static/css/2.b4cd55cc.chunk.css"
  },
  {
    "revision": "aca2805ad2c9169e54da",
    "url": "/static/js/2.a1ce559f.chunk.js"
  },
  {
    "revision": "22408e1fbe20cc72fc4e",
    "url": "/static/js/main.5b0e2e30.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "80a4ed4719ed2aa65879060f8926fb91",
    "url": "/static/media/flags.80a4ed47.png"
  },
  {
    "revision": "7de34bf24d00cb912b2b81bfefc10d03",
    "url": "/static/media/flags@2x.7de34bf2.png"
  },
  {
    "revision": "92237f69961915fb956ee34a9509a951",
    "url": "/static/media/undraw_Dest.92237f69.svg"
  },
  {
    "revision": "0545751b47f19505f4fcea792b25c4f0",
    "url": "/static/media/vHappy.0545751b.svg"
  }
]);